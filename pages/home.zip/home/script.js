document.addEventListener('DOMContentLoaded', function () {
    var cardContainer = document.getElementById('card-container');
    var loader = document.getElementById('loader');

    // Show the loader
    loader.style.display = 'block';
    fetch("/target/allscan", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then((response) => response.json())
        .then(function (data) {
            console.log(data.message);
            loader.style.display = 'none';

            data.data.result.forEach(function (item) {
                var card = document.createElement('div');
                card.classList.add('col-md-12');
                card.onclick = function () {
                    console.log(item);
                };

                var cardBody = document.createElement('div');
                cardBody.classList.add('card-body');

                var cardTitle = document.createElement('h5');
                cardTitle.classList.add('card-title');
                cardTitle.textContent = item.name;

                var cardText = document.createElement('p');
                cardText.classList.add('card-text');
                cardText.textContent = item.url;

                cardBody.appendChild(cardTitle);
                cardBody.appendChild(cardText);
                card.appendChild(cardBody);
                cardContainer.appendChild(card);
            });
        })
        .catch(function (error) {
            console.log("Error:", error);
            loader.style.display = 'none';
        });

});
